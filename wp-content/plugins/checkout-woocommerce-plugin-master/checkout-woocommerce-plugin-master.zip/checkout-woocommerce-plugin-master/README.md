Installation
============

See the [installation guide](https://github.com/CKOTech/checkout-woocommerce-plugin/wiki/Installation) on our [Wiki](https://github.com/CKOTech/checkout-woocommerce-plugin/wiki).


Webhook
=======

Url : example.com/?checkoutapipaymentListener=checkoutapi_payment_Listener

